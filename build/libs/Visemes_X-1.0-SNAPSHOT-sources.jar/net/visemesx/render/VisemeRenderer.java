package net.visemesx.render;

import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3882;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5603;
import net.minecraft.class_5604;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.client.model.*;
import net.visemesx.VisemesX;
import net.visemesx.audio.VisemeMapper;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.awt.Color;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public class VisemeRenderer<T extends class_1309, M extends class_583<T> & class_3882> extends class_3887<T, M> {
    private final class_630 base;
    private final class_5610 data;

    public VisemeRenderer(class_3883<T, M> context) {
        super(context);

        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        data = modelPartData;
        class_5606 modelPartBuilder  = class_5606.method_32108();
        List<class_5604> cuboidData = modelPartBuilder.field_27719;
        Set<class_2350> set = Set.of();
        cuboidData.add(new CustomModelCuboidData("mouthm",0,0,-4.0F, -7.8F, 4.54F, 8, 8, 8,new class_5605(0.0f),true,1,1, set));


        modelPartData.method_32117("mouth",modelPartBuilder,class_5603.method_32092(0,0,0));

        class_5607 texturedModelData = class_5607.method_32110(modelData, 640, 640);


        this.base = texturedModelData.method_32109().method_32086("mouth");
        System.out.println("[VisemesX] Render Initialized.");
    }

    @Override
    public void render(class_4587 matrices, class_4597 vertexConsumers, int light, T entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        class_630 head = method_17165().method_2838();
        // Draw a 128x128 cube
        float size = 640 / 16f; // Convert pixels to Minecraft units
        float offset = size / 2;

        // Get the current viseme

        String currentViseme = VisemesX.getInstance().getVisemeMapper().currentviseme;
        if(Objects.equals(currentViseme, "default")){currentViseme = "closed";}
        // Map visemes to colors
        float red = 1.0f;
        float green = 1.0f;
        float blue = 1.0f;


        switch (currentViseme) {
            case "closed":
                red = 1.0f;
                green = 0.0f;
                blue = 0.0f; // Red
                break;
            case "teeth":
                red = 0.0f;
                green = 1.0f;
                blue = 0.0f; // Green
                break;
            case "tongue":
                red = 0.0f;
                green = 0.0f;
                blue = 1.0f; // Blue
                break;
            case "smile":
                red = 1.0f;
                green = 1.0f;
                blue = 0.0f; // Yellow
                break;
            case "round":
                red = 1.0f;
                green = 0.0f;
                blue = 1.0f; // Magenta
                break;
            case "open":
                red = 0.0f;
                green = 1.0f;
                blue = 1.0f; // Cyan
                break;
            case "neutral":
                red = 0.5f;
                green = 0.5f;
                blue = 0.5f; // Grey
                break;
            default:
                red = 1.0f;
                green = 1.0f;
                blue = 1.0f; // White
                break;
        }




        class_1921 renderLayer = class_1921.method_23580(class_2960.method_60655(VisemesX.MOD_ID, "textures/" + currentViseme +".png"));

        class_4588 vertices = vertexConsumers.getBuffer(renderLayer);
        //vertices.color(red,green,blue,1f);

        float hoffsetScale = 250.0f;
        // make changes to the matrix


        matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0F));

        matrices.method_22907(class_7833.field_40715.rotation(-head.field_3675));
        matrices.method_22907(class_7833.field_40713.rotation(head.field_3654));
        matrices.method_22907(class_7833.field_40717.rotation(-head.field_3674));

        //matrices.translate(-hoffsetScale, hoffsetScale, hoffsetScale);
        matrices.method_22905(1, 1, 1);
        if(entity.method_5715()) {
            matrices.method_22904(0, .26, 0);
        }
        // render
        //System.out.println(this.base);
        this.base.method_22698(matrices, vertices, light, class_4608.field_21444);

        matrices.method_22905(1, 1, 1);

        //matrices.scale(1.0f, 1.0f, 1.0f);
        //matrices.translate(( -hoffsetScale) * -1.0f, (hoffsetScale) * -1.0f, (hoffsetScale) * -1.0f);

        matrices.method_22907(class_7833.field_40717.rotation(head.field_3674));
        matrices.method_22907(class_7833.field_40713.rotation(-head.field_3654));
        matrices.method_22907(class_7833.field_40715.rotation(head.field_3675));

        matrices.method_22907(class_7833.field_40715.rotationDegrees(-180.0F));

        //matrices.translate(0, 0, 0.03);

        //System.out.println("[VisemesX] "+ currentViseme+" Render Rendered.");
    }





}