package net.visemesx.render;

import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_2350;
import net.minecraft.class_5604;
import net.minecraft.class_5605;
import net.minecraft.class_630;

public class CustomModelCuboidData extends class_5604 {

    public CustomModelCuboidData(@Nullable String name, float textureX, float textureY, float offsetX, float offsetY, float offsetZ, float sizeX, float sizeY, float sizeZ, class_5605 extra, boolean mirror, float textureScaleX, float textureScaleY, Set<class_2350> directions) {
        super(name, textureX, textureY, offsetX, offsetY, offsetZ, sizeX, sizeY, sizeZ, extra, mirror, textureScaleX, textureScaleY, directions);
    }

    @Override
    public class_630.class_628 method_32093(int textureWidth, int textureHeight) {
        // Also use AW to get fields from this class to pass it into your CustomCuboid
        return new CustomCuboid((int)this.field_27713.method_32118(), (int)this.field_27713.method_32119(), this.field_27709.x(), this.field_27709.y(), this.field_27709.z(), this.field_27710.x(), this.field_27710.y(), this.field_27710.z(), this.field_27711.field_27716, this.field_27711.field_27717, this.field_27711.field_27718, this.field_27712, (float)textureWidth * this.field_27714.method_32118(), (float)textureHeight * this.field_27714.method_32119(), this.field_42887);
    }
}