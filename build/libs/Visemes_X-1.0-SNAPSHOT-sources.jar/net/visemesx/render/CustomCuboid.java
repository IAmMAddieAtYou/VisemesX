package net.visemesx.render;

import java.util.Set;
import net.minecraft.class_2350;
import net.minecraft.class_630;

public class CustomCuboid extends class_630.class_628 {




    public CustomCuboid(int u, int v, float x, float y, float z, float sizeX, float sizeY, float sizeZ, float extraX, float extraY, float extraZ, boolean mirror, float textureWidth, float textureHeight, Set<class_2350> set) {
        super(u, v, x, y, z, sizeX, sizeY, sizeZ, extraX, extraY, extraZ, mirror, textureWidth, textureHeight, Set.of());
        float f = x + sizeX;
        float g = y + sizeY;
        float h = z + sizeZ;
        class_630.class_618 vertex = new class_630.class_618(x, y, z, 0.0F, 0.0F);
        class_630.class_618 vertex2 = new class_630.class_618(f, y, z, 0.0F, 8.0F);
        class_630.class_618 vertex3 = new class_630.class_618(f, g, z, 8.0f, 8.0f);
        class_630.class_618 vertex4 = new class_630.class_618(x, g, z, 8.0f, 0.0f);
        class_630.class_618 vertex5 = new class_630.class_618(x, y, h, 0.0F, 0.0F);
        class_630.class_618 vertex6 = new class_630.class_618(f, y, h, 0.0F, 8.0F);
        class_630.class_618 vertex7 = new class_630.class_618(f, g, h, 8.0f, 8.0f);
        class_630.class_618 vertex8 = new class_630.class_618(x, g, h, 8.0f, 0.0f);
        // here is important to pass an empty set(last argument) of the directions to avoid unnecessary side creating because
        // we will override them anyway, check your case

        // take the necessary vertex from the original code, you can copy them
        // For example we take top quad:
        class_630.class_593 BackQuad = new class_630.class_593(new class_630.class_618[]{vertex2, vertex, vertex4, vertex3}, 0, 0, 640, 640, textureWidth, textureHeight, mirror, class_2350.field_11035);
        // the important part here to change uv values for it
        // In your case it could be something like 0, 0, 640, 640

        // also remove final modifier from side field to override it here
        this.field_3649 = new class_630.class_593[]{BackQuad};
    }
}