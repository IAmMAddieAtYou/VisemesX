package net.visemesx;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.visemesx.gui.VisemesXGUI;

public class KeyBindHandler {
    public static class_304 OPEN_GUI;

    public static void registerKeybinds() {
        OPEN_GUI = KeyBindingHelper.registerKeyBinding(new class_304(
                "Open Menu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                "VisemesX Misc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_GUI.method_1436()) {
                class_310.method_1551().method_1507(new VisemesXGUI());
            }
        });
    }
}