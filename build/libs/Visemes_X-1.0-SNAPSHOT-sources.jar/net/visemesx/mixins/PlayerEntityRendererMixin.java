package net.visemesx.mixins;

import net.minecraft.class_1007;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import net.visemesx.render.VisemeRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin extends class_922<class_742, class_591<class_742>> {
    public PlayerEntityRendererMixin(class_5617.class_5618 ctx, class_591<class_742> model, float shadowRadius) {
        super(ctx, model, shadowRadius);
    }

    @Inject(method = "<init>*", at = @At("RETURN"))
    public void init(class_5617.class_5618 ctx, boolean slim, CallbackInfo ci) {
        this.method_4046(new VisemeRenderer<>(this));
        System.out.println("[VisemesX] Render Added.");
    }
}