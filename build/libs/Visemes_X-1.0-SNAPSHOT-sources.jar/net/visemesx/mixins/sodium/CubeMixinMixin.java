package net.visemesx.mixins.sodium;

import com.bawnorton.mixinsquared.TargetHandler;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;
import net.minecraft.class_630.class_628;
import net.visemesx.render.CustomCuboid;
@Pseudo
@Mixin(class_628.class)
public class CubeMixinMixin {

    @Dynamic
    @TargetHandler(
            mixin = "net.caffeinemc.mods.sodium.mixin.features.render.entity.CubeMixin",
            name = "onCompile",
            prefix = "handler"
    )
    @Inject(method = "@MixinSquared:Handler", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void helloSodium(class_4665 pose, class_4588 buffer, int light, int overlay, int color, CallbackInfo a, CallbackInfo b) {
        class_628 cuboid = (class_628) (Object) this;
        if (!(cuboid instanceof CustomCuboid)) {
            return;
        }
        b.cancel();
    }
}
