package net.visemesx.network;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_8710.class_9154;

public class VisemeNetwork {
    private static final class_2960 EXPRESSION_SYNC_PACKET = class_2960.method_60655("visemesx", "expression_sync");



    public static void registerPackets() {
        // Register the global receiver for the packet
        class_9154<class_8710> id = new class_9154<>(EXPRESSION_SYNC_PACKET);
        ServerPlayNetworking.registerGlobalReceiver(id, (buf, context) -> {
            String viseme = buf.toString(); // Read the string payload from the buffer
            System.out.println("[VisemesX] Received viseme: " + viseme);

            // Modify the world on the server thread (must execute on the server thread)
            context.server().execute(() -> {
                broadcastExpressionUpdate(viseme, (class_3222) context.player());
            });
        });

        // Confirm the packet registration
        System.out.println("[VisemesX] Expression sync packet registered.");
    }



    private static void broadcastExpressionUpdate(String viseme, class_3222 sender) {
        class_2540 buf = new class_2540(PacketByteBufs.create());
        buf.method_10814(viseme);

        // Broadcast the viseme to all players connected to the server
        for (class_3222 player : sender.method_5682().method_3760().method_14571()) {
            System.out.println("[VisemesX] Broadcasting viseme: " + viseme);
            ServerPlayNetworking.send(player, (class_8710) buf);
        }
    }

    public static void sendExpressionUpdate(class_2540 buf) {
        System.out.println("[VisemesX] Sending viseme update.");
        ClientPlayNetworking.send((class_8710) buf);
    }
}
