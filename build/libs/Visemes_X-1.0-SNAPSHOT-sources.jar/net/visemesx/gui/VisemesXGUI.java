package net.visemesx.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_7842;
import net.minecraft.class_7919;
import net.minecraft.client.gui.widget.*;
import net.visemesx.VisemesX;
import net.visemesx.audio.AudioCapture;

import java.util.List;

public class VisemesXGUI extends class_437 {
    private int activeTab = 0; // 0 = Import, 1 = Emotions, 2 = Voice, 3 = Presets
    private class_4265<MicrophoneEntry> microphoneListWidget;
    private class_357 sensitivitySlider;
    private static final class_2561 SENSITIVITY_TEXT = class_2561.method_43471("Microphone Sensitivity: ");
    private static final class_2561 MICROPHONE_TEXT = class_2561.method_43471("Microphone");

    public VisemesXGUI() {
        super(class_2561.method_30163("VisemesX - Voice & Expression Mod"));
    }

    @Override
    protected void method_25426() {
        // Top Navigation Buttons
        this.method_37063(
                class_4185.method_46430(class_2561.method_30163("📂 Import"), button -> setTab(0))
                        .method_46434(this.field_22789 / 2 - 120, 40, 80, 20)
                        .method_46436(class_7919.method_47407(class_2561.method_30163("Import button")))
                        .method_46431()
        );

        this.method_37063(
                class_4185.method_46430(class_2561.method_30163("🎭 Emotions"), button -> setTab(1))
                        .method_46434(this.field_22789 / 2 - 40, 40, 80, 20)
                        .method_46436(class_7919.method_47407(class_2561.method_30163("Emoticons button")))
                        .method_46431()
        );

        this.method_37063(
                class_4185.method_46430(class_2561.method_30163("🎙️ Voice"), button -> setTab(2))
                        .method_46434(this.field_22789 / 2 + 40, 40, 80, 20)
                        .method_46436(class_7919.method_47407(class_2561.method_30163("Voice button")))
                        .method_46431()
        );

        this.method_37063(
                class_4185.method_46430(class_2561.method_30163("💾 Presets"), button -> setTab(3))
                        .method_46434(this.field_22789 / 2 + 120, 40, 80, 20)
                        .method_46436(class_7919.method_47407(class_2561.method_30163("Presets button")))
                        .method_46431()
        );
        updateTab();
    }

    private void setTab(int tab) {
        this.activeTab = tab;
        this.method_37067();
        this.method_25426();
    }
    private void importSkinZip() {
        // TODO: Implement the ZIP import logic
        System.out.println("Import ZIP clicked!");
    }

    private void StopMic() {
        VisemesX.getInstance().getAudioCapture().stopCapture();
    }
    private void StartMic() {
        VisemesX.getInstance().getAudioCapture().startCapture();
    }

    private void assignEmotion(int slot) {
        // TODO: Implement the ZIP import logic
        System.out.println("Import ZIP clicked!");
    }
    private void setMicSensitivity(float value) {
        VisemesX.getInstance().getPhonemeProcessor().micsensitivity = value;
        System.out.println("SETMIC " + VisemesX.getInstance().getPhonemeProcessor().micsensitivity);
    }

    private void savePreset() {
        // TODO: Implement the ZIP import logic
        System.out.println("Import ZIP clicked!");
    }

    private void updateTab() {
        switch (activeTab) {
            case 0 -> showImportTab();
            case 1 -> showEmotionsTab();
            case 2 -> showVoiceSettingsTab();
            case 3 -> showPresetsTab();
        }
    }
    private void showImportTab() {
        this.method_37063(
                class_4185.method_46430(class_2561.method_30163("📂 Import ZIP"), button -> importSkinZip())
                        .method_46434(this.field_22789 / 2 - 50, 110, 100, 20)
                        .method_46435((btn) -> (net.minecraft.class_5250) class_2561.method_30163("Import ZIP button"))
                        .method_46431()
        );
    }

    private void showEmotionsTab() {
        for (int i = 0; i < 9; i++) {
            final int slot = i;  // Make 'slot' final
            this.method_37063(
                    class_4185.method_46430(class_2561.method_30163("E" + (i + 1)), button -> assignEmotion(slot))
                            .method_46434(20 + (i * 30), 110, 30, 20)
                            .method_46435((btn) -> class_2561.method_43470("Emotion " + (slot + 1) + " button"))
                            .method_46431()
            );
        }
    }

    private void showVoiceSettingsTab() {
        int labelY = 80;
        int controlY = 50;
        int controlWidth = 150;

        int textHeight = 10;
        class_7842 t = new class_7842(class_2561.method_30163("visemesx.audio_input_settings"), this.field_22793);
        t.method_46419(50);
        t.method_46421(this.field_22789 / 2);

        this.method_37063(
                t
        );
        class_7842 tm = new class_7842(MICROPHONE_TEXT, this.field_22793);
        tm.method_46419(70);
        tm.method_46421(this.field_22789 / 2);
        this.method_37063(
                tm
        );

        AudioCapture audioCapture = VisemesX.getInstance().getAudioCapture();
        List<String> microphoneNames = audioCapture.getCaptureDeviceNames();

        if (!microphoneNames.isEmpty()) {
            microphoneListWidget = new class_4265<MicrophoneEntry>(this.field_22787, controlWidth,  controlY, 0, controlY){};
            microphoneListWidget.method_53533(60);
            microphoneListWidget.method_46421(40);
            microphoneListWidget.method_46419(0);
            microphoneListWidget.method_25358(100);

            for (String name : microphoneNames) {
                microphoneListWidget.method_25321(new MicrophoneEntry(name, this::onMicrophoneSelected));
            }
            this.method_37063(microphoneListWidget);

        } else {
            this.method_37063(class_4185.method_46430(class_2561.method_43471("visemesx.error.no_microphones"), button -> {}).method_46434(this.field_22789 / 2, controlY, controlWidth, 20).method_46431());
        }


        this.method_37063(class_4185.method_46430(class_2561.method_43471("Start Visemes"), button -> {this.StartMic();}).method_46434(20, this.field_22790 - 40, 30, 40).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43471("Stop Visemes"), button -> {this.StopMic();}).method_46434(this.field_22789 - 60, this.field_22790 - 40, 30, 40).method_46431());
        sensitivitySlider = new class_357(this.field_22789 / 2, controlY + 90, controlWidth, 20, class_2561.method_30163(""), VisemesX.getInstance().getPhonemeProcessor().micsensitivity) {
            @Override
            protected void method_25346() {

            }


            @Override
            protected void method_25344() {
                VisemesXGUI.this.setMicSensitivity((float) this.field_22753);
            }
        };
        class_7842 st = new class_7842(class_2561.method_30163("Microphone Sensitivity: "+ sensitivitySlider.field_22753), this.field_22793);
        st.method_46421(sensitivitySlider.method_46426());
        st.method_46419(sensitivitySlider.method_46427() - 20);
        this.method_37063(
                st
        );
        this.method_37063(sensitivitySlider);
    }

    public void onMicrophoneSelected(String microphoneName) {
        AudioCapture audioCapture = VisemesX.getInstance().getAudioCapture();
        int index = audioCapture.getCaptureDeviceIndex(microphoneName);
        audioCapture.selectedindex = index;
        if (index != -1) {
            if(VisemesX.getInstance().getAudioCapture().capturing) {
                VisemesX.getInstance().restartAudioCapture();
            }
            System.out.println("Selected microphone: " + microphoneName + " (Index: " + index + ")");
        } else {
            System.out.println("Error: Could not find index for microphone: " + microphoneName);
        }
    }

    private void showPresetsTab() {
        this.method_37063(
                class_4185.method_46430(class_2561.method_30163("💾 Save Preset"), button -> savePreset())
                        .method_46434(this.field_22789 / 2 - 50, 110, 100, 20)
                        .method_46435((btn) -> (net.minecraft.class_5250) class_2561.method_30163("Save Preset button"))
                        .method_46431()
        );
    }

    public void drawCenteredText(class_332 textc,class_4587 matrices, class_2561 text, int x, int y, int color) {
        // Get the width of the text
        int textWidth = this.field_22793.method_27525(text);

        // Calculate the position so that the text is centered
        int xPosition = x - textWidth / 2;

        // Use the textRenderer to draw the text at the calculated position
        textc.method_51439(this.field_22793,text,x,y,color,true);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context,mouseX,mouseY,delta); // Render background (if necessary)
        super.method_25394(context, mouseX, mouseY, delta); // Calls the parent class's render method


        // Access the matrix stack from the context
        class_4587 matrices = context.method_51448();

        // Custom rendering logic
        drawCenteredText(context,matrices, class_2561.method_30163("VisemesX - Voice & Expression Mod"), this.field_22789 / 2, 20, 0xFFFFFF);

    }


    private class MicrophoneEntry extends class_4265.class_4266<MicrophoneEntry> {
        private final String microphoneName;
        private final class_4185 selectButton;
        private final VisemesXGUI parentScreen;

        public MicrophoneEntry(String microphoneName, java.util.function.Consumer<String> onSelect) {
            super();
            this.microphoneName = microphoneName;
            this.parentScreen = VisemesXGUI.this;
            this.selectButton = class_4185.method_46430(class_2561.method_43470(microphoneName), button -> onSelect.accept(microphoneName))
                    .method_46432(parentScreen.microphoneListWidget.method_25322() - 10)
                    .method_46431();
        }

        @Override
        public void method_25343(class_332 context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
            this.selectButton.method_46421(x + 2);
            this.selectButton.method_46419(y - 10);
            this.selectButton.method_25394(context, mouseX, mouseY, tickDelta);
        }

        @Override
        public List<? extends class_364> method_25396() {
            return List.of(this.selectButton);
        }

        @Override
        public List<? extends net.minecraft.class_6379> method_37025() {
            return List.of(this.selectButton);
        }
    }
}
